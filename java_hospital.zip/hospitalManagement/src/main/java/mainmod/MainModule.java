package mainmod;
import dao.HospitalServiceImpl;
import entity.Appointment;
import java.util.List;
import java.util.Scanner;

public class MainModule {
    public static void main(String[] args) {
        HospitalServiceImpl hospitalService = new HospitalServiceImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Get Appointment by ID");
            System.out.println("2. Get Appointments for Patient");
            System.out.println("3. Get Appointments for Doctor");
            System.out.println("4. Schedule Appointment");
            System.out.println("5. Update Appointment");
            System.out.println("6. Cancel Appointment");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Appointment ID: ");
                    int appointmentId = scanner.nextInt();
				Appointment appointment = hospitalService.getAppointmentById(appointmentId);
				System.out.println(appointment);
                    break;

                case 2:
                    System.out.print("Enter Patient ID: ");
                    int patientId = scanner.nextInt();
                    Appointment patientAppointments = hospitalService.getAppointmentById(patientId);
                    break;

                case 3:
                    System.out.print("Enter Doctor ID: ");
                    int doctorId = scanner.nextInt();
                
                    List<Appointment> doctorAppointments = hospitalService.getAppointmentsForDoctor(doctorId);
                    break;

                case 4:
                    System.out.print("Enter Patient ID: ");
                    int newPatientId = scanner.nextInt();
                    System.out.print("Enter Doctor ID: ");
                    int newDoctorId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                    String appointmentDate = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String description = scanner.nextLine();
                    Appointment newAppointment = new Appointment(0, newPatientId, newDoctorId, appointmentDate, description);
                   
                    break;

                case 5:
                    System.out.print("Enter Appointment ID: ");
                    int updateAppointmentId = scanner.nextInt();
                    System.out.print("Enter Patient ID: ");
                    int updatePatientId = scanner.nextInt();
                    System.out.print("Enter Doctor ID: ");
                    int updateDoctorId = scanner.nextInt();
                    scanner.nextLine();  
                    System.out.print("Enter Appointment Date (YYYY-MM-DD): ");
                    String updateAppointmentDate = scanner.nextLine();
                    System.out.print("Enter Description: ");
                    String updateDescription = scanner.nextLine();
                    Appointment updateAppointment = new Appointment(updateAppointmentId, updatePatientId, updateDoctorId, updateAppointmentDate, updateDescription);
                    
                    break;

                case 6:
                    System.out.print("Enter Appointment ID: ");
                    int cancelAppointmentId = scanner.nextInt();
                    
                    break;

                case 7:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}